"use strict";
{
    angular.module("app")
        .component ("todo",{
            controller:"toDoController",
            templateUrl:"ToDo/todo.html"

        })
     
}

